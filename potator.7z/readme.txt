Potator 0.70
------------

* Can now specify a rom to load from command line (space1)


Special thanks to Peter Trauner and Death adder for their help

contact: david.raingeard@laposte.net
